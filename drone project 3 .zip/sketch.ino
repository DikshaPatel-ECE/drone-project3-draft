#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <DHT.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
Adafruit_MPU6050 mpu;

#define DHTPIN 2
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

#define REDLED 8
#define GREENLED 9
#define BUZZER 7
#define BUTTON 6

bool crashed = false;

void setup() {

  pinMode(REDLED, OUTPUT);
  pinMode(GREENLED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(BUTTON, INPUT);

  Serial.begin(9600);

  dht.begin();

  display.begin(SSD1306_SWITCHCAPVCC,0x3C);
  display.clearDisplay();

  if(!mpu.begin()){
    while(1);
  }

  display.setTextSize(2);
  display.setTextColor(WHITE);

  display.setCursor(10,20);
  display.println("BOOTING");
  display.display();

  delay(2000);
}

void loop() {

  sensors_event_t a,g,temp;
  mpu.getEvent(&a,&g,&temp);

  float temperature = dht.readTemperature();

  float ax = a.acceleration.x;
  float ay = a.acceleration.y;
  float az = a.acceleration.z;

  float tilt = sqrt(ax*ax + ay*ay);

  if(digitalRead(BUTTON)==HIGH){

    crashed=false;

    noTone(BUZZER);

    digitalWrite(REDLED,LOW);
    digitalWrite(GREENLED,HIGH);

    display.clearDisplay();
    display.setCursor(0,20);
    display.println("RESET");
    display.display();

    delay(1500);
  }

  display.clearDisplay();

  if(temperature>40){

    digitalWrite(REDLED,HIGH);
    digitalWrite(GREENLED,LOW);

    tone(BUZZER,1000);

    display.setTextSize(1);
    display.setCursor(0,0);
    display.print("TEMP:");
    display.println(temperature);

    display.setTextSize(2);
    display.setCursor(0,30);
    display.println("HOT!");

  }

  else if(tilt>8){

    crashed=true;

    digitalWrite(GREENLED,LOW);

    digitalWrite(REDLED,!digitalRead(REDLED));

    tone(BUZZER,1200);
    delay(200);
    noTone(BUZZER);
    delay(200);

    display.setTextSize(1);

    display.setCursor(0,0);
    display.print("Tilt:");
    display.println(tilt);

    display.setCursor(0,12);
    display.print("Temp:");
    display.println(temperature);

    display.setTextSize(2);

    display.setCursor(0,35);
    display.println("CRASH");

  }

  else if(tilt>4){

    digitalWrite(GREENLED,!digitalRead(GREENLED));
    digitalWrite(REDLED,LOW);

    noTone(BUZZER);

    display.setTextSize(1);

    display.setCursor(0,0);
    display.print("Tilt:");
    display.println(tilt);

    display.setCursor(0,12);
    display.print("Temp:");
    display.println(temperature);

    display.setTextSize(2);

    display.setCursor(0,35);
    display.println("WARNING");

    delay(300);

  }

  else{

    digitalWrite(GREENLED,HIGH);
    digitalWrite(REDLED,LOW);

    noTone(BUZZER);

    display.setTextSize(1);

    display.setCursor(0,0);
    display.print("TEMP:");
    display.print(temperature);
    display.println(" C");

    display.setCursor(0,12);
    display.print("Tilt:");
    display.println(tilt);

    display.setTextSize(2);

    display.setCursor(0,35);
    display.println("SAFE");
  }

  display.display();

  delay(200);

}